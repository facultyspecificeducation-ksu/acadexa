"""
================================================================================
Export Service for Acadexa API
================================================================================

Business logic for data export:
- Export student list to Excel
- Export at-risk students to Excel/PDF
- Export analysis issues to Excel/PDF

Security: Uses authenticated Supabase client to respect RLS.
All queries use proper joins to avoid N+1 patterns.

Author: Acadexa Team
Version: 1.0.0
================================================================================
"""

import json
import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any
from uuid import UUID

from supabase import Client

from app.core.exceptions import NotFoundError

logger = logging.getLogger("acadexa.services.export")


class ExportService:
    """
    Service for data export with RLS compliance.
    
    All queries respect user permissions through authenticated client.
    Optimized with proper joins to eliminate N+1 patterns.
    """
    
    def __init__(self, supabase_client: Client):
        """
        Initialize ExportService with authenticated Supabase client.
        
        Args:
            supabase_client: Supabase client with user's JWT token.
        """
        self._supabase = supabase_client
    
    async def export_students_list(
        self,
        search: Optional[str] = None,
        department_id: Optional[UUID] = None,
        curriculum_id: Optional[UUID] = None,
        current_level: Optional[int] = None,
        academic_status: Optional[str] = None,
        risk_level: Optional[str] = None,
        enrollment_year: Optional[int] = None,
        is_active: Optional[bool] = None,
    ) -> bytes:
        """
        Export filtered student list to Excel.
        
        Optimized with single query using left join to latest_academic_analyses view.
        Eliminates N+1 pattern.
        
        Args:
            Same filters as GET /students endpoint
            
        Returns:
            Excel file bytes (JSON placeholder for MVP)
        """
        # Build query with left join to latest_academic_analyses view
        # This eliminates the N+1 pattern by fetching status in the same query
        query = self._supabase.table("students")\
            .select(
                "student_code, name, enrollment_year, current_level, cumulative_gpa, "
                "attempted_hours, completed_hours, completion_rate, is_active, "
                "departments(name_ar), curricula(name_ar, regulation_year), "
                "latest_academic_analyses(academic_status, risk_level, graduation_eligible)"
            )
        
        # Apply filters
        if search:
            query = query.or_(f"student_code.ilike.%{search}%,name.ilike.%{search}%")
        
        if department_id:
            query = query.eq("department_id", str(department_id))
        
        if curriculum_id:
            query = query.eq("curriculum_id", str(curriculum_id))
        
        if current_level:
            query = query.eq("current_level", current_level)
        
        if enrollment_year:
            query = query.eq("enrollment_year", enrollment_year)
        
        if is_active is not None:
            query = query.eq("is_active", is_active)
        
        # Apply academic_status filter using the joined view
        if academic_status:
            query = query.eq("latest_academic_analyses.academic_status", academic_status)
        
        # Apply risk_level filter using the joined view
        if risk_level:
            query = query.eq("latest_academic_analyses.risk_level", risk_level)
        
        result = query.execute()
        students = result.data or []
        
        # Flatten the nested latest_academic_analyses data
        for student in students:
            analysis = student.pop("latest_academic_analyses", {})
            student["academic_status"] = analysis.get("academic_status")
            student["risk_level"] = analysis.get("risk_level")
            student["graduation_eligible"] = analysis.get("graduation_eligible")
            
            # Flatten department data
            dept = student.pop("departments", {})
            student["department_name_ar"] = dept.get("name_ar")
            
            # Flatten curriculum data
            curr = student.pop("curricula", {})
            student["curriculum_name_ar"] = curr.get("name_ar")
            student["regulation_year"] = curr.get("regulation_year")
        
        # Generate Excel (simplified - will use openpyxl in production)
        # For MVP, return JSON placeholder
        return json.dumps({
            "students": students,
            "total": len(students),
            "exported_at": datetime.now(timezone.utc).isoformat(),
        }).encode()
    
    async def export_at_risk_students(
        self,
        department_id: Optional[UUID] = None,
        format: str = "xlsx",
    ) -> bytes:
        """
        Export at-risk students to Excel or PDF.
        
        Uses latest_academic_analyses view directly - already optimized.
        
        Args:
            department_id: Optional department filter
            format: Export format (xlsx or pdf)
            
        Returns:
            File bytes (JSON placeholder for MVP)
        """
        query = self._supabase.table("latest_academic_analyses")\
            .select(
                "student_id, risk_level, analyzed_at, "
                "students!inner(student_code, name, cumulative_gpa, department_id, departments!inner(name_ar))"
            )\
            .eq("risk_level", "high")
        
        if department_id:
            query = query.eq("students.department_id", str(department_id))
        
        result = query.execute()
        
        students = []
        for item in result.data or []:
            student_info = item.get("students", {})
            dept_info = student_info.get("departments", {}) if student_info else {}
            
            students.append({
                "student_code": student_info.get("student_code"),
                "name": student_info.get("name"),
                "cumulative_gpa": student_info.get("cumulative_gpa"),
                "department_name_ar": dept_info.get("name_ar"),
                "risk_level": item.get("risk_level"),
                "analyzed_at": item.get("analyzed_at"),
            })
        
        return json.dumps({
            "students": students,
            "total": len(students),
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "format": format,
        }).encode()
    
    async def export_analysis_issues(
        self,
        student_id: UUID,
        format: str = "xlsx",
    ) -> bytes:
        """
        Export a student's analysis issues to Excel or PDF.
        
        Single optimized query with proper joins.
        
        Args:
            student_id: Student UUID
            format: Export format (xlsx or pdf)
            
        Returns:
            File bytes (JSON placeholder for MVP)
        """
        # Single query to get analysis and issues together
        # First, verify student exists and get latest analysis
        result = self._supabase.table("latest_academic_analyses")\
            .select(
                "id, academic_status, risk_level, graduation_eligible, analyzed_at, "
                "analysis_issues(rule_code, severity, title_ar, description_ar, recommendation_ar, resolved, created_at)"
            )\
            .eq("student_id", str(student_id))\
            .execute()
        
        if not result.data:
            return json.dumps({"issues": [], "message": "No analysis found"}).encode()
        
        analysis = result.data[0]
        issues = analysis.pop("analysis_issues", []) if analysis else []
        
        return json.dumps({
            "analysis": analysis,
            "issues": issues,
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "format": format,
        }).encode()